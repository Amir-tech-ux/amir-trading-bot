
# Maayan Telegram Bot (Render Worker)

בוט טלגרם בסיסי עבור מערכת "מעין" — מוכן לפריסה דרך GitHub + Render (Worker).

## מה יש כאן
- `bot.py` — קוד הבוט (Polling)
- `requirements.txt` — ספריות לתלות
- `Procfile` — הפעלת Worker ב-Render
- `.env.example` — דוגמה למשתני סביבה

## איך מפעילים (צעד-אחר-צעד)
1. **צור בוט אצל BotFather בטלגרם** וקבל Token (לשמור בסוד).
2. הורד את ה-ZIP, חלץ לתיקיה והעלה את התוכן ל-GitHub (Repository חדש).
3. היכנס ל-[Render](https://render.com), בחר **New +** → **Blueprint/Repo** → חבר את הרפו.
4. בחר סוג שירות **Worker** (לא Web).
5. ודא שב-`Procfile` יש: `worker: python bot.py`.
6. תחת *Environment* הוסף משתני סביבה:
   - `TELEGRAM_TOKEN` — ה-Token שקיבלת מ-BotFather.
   - `ADMIN_CHAT_ID` — (אופציונלי) ה-Chat ID שלך להגבלת /alert.
7. Deploy. בסיום, פתח טלגרם ושלח לבוט `/start`, ואז `/ping`.

### איך מוצאים Chat ID?
שלח לבוט `/id` והוא יחזיר את ה-Chat ID שלך. העתק את המספר והדבק ב-`ADMIN_CHAT_ID` ב-Render.

### שליחת התראות באופן ידני
אם הגדרת `ADMIN_CHAT_ID`, רק אתה תוכל להשתמש בפקודה:
```
/alert טקסט ההתראה
```

## הערות
- שימוש ב-Polling מתאים ל-Render Worker ואינו דורש Webhook או פורט פתוח.
- בהמשך ניתן להחליף ל-Webhooks במידה ותעבור לשירות Web קבוע.
