
import os
import logging
from typing import Final
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

TOKEN: Final[str] = os.getenv("TELEGRAM_TOKEN", "").strip()
ADMIN_CHAT_ID: Final[str] = os.getenv("ADMIN_CHAT_ID", "").strip()  # optional

if not TOKEN:
    raise SystemExit("Missing TELEGRAM_TOKEN env var. Set it in Render > Environment.")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    name = user.full_name if user else "there"
    await update.message.reply_text(f"שלום {name}! הבוט פעיל. /ping לבדיקה, /help לעזרה.")

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "פקודות זמינות:\n"
        "/ping - בדיקת חיים\n"
        "/alert <טקסט> - שליחת התראה (מוגבל לאדמין, אם הוגדר ADMIN_CHAT_ID)\n"
        "/id - קבלת ה-Chat ID הנוכחי"
    )

async def ping(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("pong ✅")

async def chat_id(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    cid = update.effective_chat.id if update.effective_chat else "unknown"
    await update.message.reply_text(f"Chat ID: {cid}")

async def alert(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if ADMIN_CHAT_ID:
        # Only allow the configured admin to use /alert
        if str(update.effective_chat.id) != str(ADMIN_CHAT_ID):
            await update.message.reply_text("⛔ הפקודה /alert זמינה רק לאדמין.")
            return
    # Combine the text after /alert
    msg = " ".join(context.args).strip()
    if not msg:
        await update.message.reply_text("שימוש: /alert טקסט ההתראה")
        return
    await update.message.reply_text(f"📢 התראה נשלחה: {msg}")

async def echo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    # Simple echo for testing; you can remove later
    await update.message.reply_text(update.message.text)

def main() -> None:
    application = Application.builder().token(TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_cmd))
    application.add_handler(CommandHandler("ping", ping))
    application.add_handler(CommandHandler("id", chat_id))
    application.add_handler(CommandHandler("alert", alert))

    # Fallback echo handler
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, echo))

    # Long polling (Render Worker)
    application.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
